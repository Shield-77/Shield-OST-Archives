#include "ia_http.h"
#include <3ds.h>
#include <curl/curl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#define SOCKET_BYTES 0x100000

static LightLock lock;
static Thread worker;
static void *socket_buffer;
extern const unsigned char shield_ca_bundle_start[];
extern const unsigned char shield_ca_bundle_end[];
static const char *ca_bundle;
static size_t ca_size;
static HttpSnapshot current;
static bool initialized, running, cancel_requested;
static char request_url[768], request_file[512];
static size_t request_max;
static bool request_range;
static char *response_body;
static size_t response_length;
static char init_error[120];

typedef struct {
    FILE *file;
    char *body;
    size_t used, cap, limit;
    bool overflow, write_error;
} Sink;

static size_t on_data(char *data, size_t size, size_t count, void *ctx) {
    Sink *sink=ctx;
    if (size && count > SIZE_MAX/size) return 0;
    size_t bytes=size*count;
    if (bytes>sink->limit-sink->used) { sink->overflow=true; return 0; }
    if (sink->file) {
        if (fwrite(data,1,bytes,sink->file)!=bytes) { sink->write_error=true; return 0; }
    } else {
        if (sink->used+bytes+1>sink->cap) {
            size_t next=sink->cap ? sink->cap*2 : 8192;
            while (next<sink->used+bytes+1) next*=2;
            if (next>sink->limit+1) next=sink->limit+1;
            char *buffer=realloc(sink->body,next);
            if (!buffer) { sink->write_error=true; return 0; }
            sink->body=buffer; sink->cap=next;
        }
        memcpy(sink->body+sink->used,data,bytes);
        sink->body[sink->used+bytes]=0;
    }
    sink->used+=bytes;
    LightLock_Lock(&lock); current.received=sink->used; LightLock_Unlock(&lock);
    return bytes;
}

static int on_progress(void *unused, curl_off_t total, curl_off_t now,
                       curl_off_t upload_total, curl_off_t upload_now) {
    (void)unused; (void)upload_total; (void)upload_now;
    LightLock_Lock(&lock);
    current.expected=total>0 ? (uint64_t)total : 0;
    if (now>0) current.received=(uint64_t)now;
    bool cancelled=cancel_requested;
    LightLock_Unlock(&lock);
    return cancelled ? 1 : 0;
}

static void run_request(void *unused) {
    (void)unused;
    Sink sink={0}; sink.limit=request_max;
    bool file_request=request_file[0]!=0;
    if (file_request) {
        sink.file=fopen(request_file,"wb");
        if (!sink.file) {
            LightLock_Lock(&lock);
            snprintf(current.error,sizeof(current.error),"Ecriture SD impossible.");
            current.state=HTTP_ERROR; running=false;
            LightLock_Unlock(&lock);
            return;
        }
    }
    CURL *curl=curl_easy_init();
    CURLcode result=CURLE_FAILED_INIT;
    long status=0;
    if (curl) {
        struct curl_blob ca={.data=(void *)ca_bundle,.len=ca_size,.flags=CURL_BLOB_NOCOPY};
        bool configured =
            curl_easy_setopt(curl,CURLOPT_URL,request_url)==CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_USERAGENT,"ShieldOnlineArchive/0.2.1") == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_PROTOCOLS_STR,"https") == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_REDIR_PROTOCOLS_STR,"https") == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_CAINFO_BLOB,&ca) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,1L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_MAXREDIRS,4L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,10L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_LOW_SPEED_LIMIT,256L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_LOW_SPEED_TIME,30L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_NOPROGRESS,0L) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_XFERINFOFUNCTION,on_progress) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,on_data) == CURLE_OK &&
            curl_easy_setopt(curl,CURLOPT_WRITEDATA,&sink) == CURLE_OK;
        if (configured) {
            curl_easy_setopt(curl,CURLOPT_TIMEOUT,file_request ? 0L : 25L);
            if (request_range) {
                char range[48];
                snprintf(range,sizeof(range),"0-%lu",(unsigned long)(request_max-1));
                configured=curl_easy_setopt(curl,CURLOPT_RANGE,range)==CURLE_OK;
                if (configured) result=curl_easy_perform(curl);
            } else result=curl_easy_perform(curl);
            curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&status);
        }
        curl_easy_cleanup(curl);
    }
    if (sink.file && fclose(sink.file)!=0) sink.write_error=true;
    bool success=result==CURLE_OK && (status==200 || (request_range && status==206)) &&
        !sink.overflow && !sink.write_error;
    LightLock_Lock(&lock);
    current.status=status;
    current.received=sink.used;
    if (success) {
        response_body=sink.body; response_length=sink.used; sink.body=NULL;
        current.state=HTTP_DONE;
    } else {
        current.state=HTTP_ERROR;
        if (cancel_requested) snprintf(current.error,sizeof(current.error),"Operation annulee.");
        else if (sink.overflow) snprintf(current.error,sizeof(current.error),"Fichier trop volumineux.");
        else if (sink.write_error) snprintf(current.error,sizeof(current.error),"Ecriture SD ou memoire impossible.");
        else if (status!=200 && status>0) snprintf(current.error,sizeof(current.error),"Serveur HTTP %ld.",status);
        else snprintf(current.error,sizeof(current.error),"Reseau : %s",curl_easy_strerror(result));
    }
    running=false;
    LightLock_Unlock(&lock);
    if (file_request && !success) remove(request_file);
    free(sink.body);
}

bool ia_http_init(void) {
    LightLock_Init(&lock);
    if (initialized) return true;
    ca_bundle=(const char *)shield_ca_bundle_start;
    ca_size=(size_t)(shield_ca_bundle_end-shield_ca_bundle_start);
    if (!ca_size || ca_size>400000) {
        snprintf(init_error,sizeof(init_error),"Certificats HTTPS absents."); return false;
    }
    socket_buffer=memalign(0x1000,SOCKET_BYTES);
    if (!socket_buffer || socInit(socket_buffer,SOCKET_BYTES)!=0) {
        free(socket_buffer); socket_buffer=NULL;
        snprintf(init_error,sizeof(init_error),"Wi-Fi ou memoire reseau indisponible."); return false;
    }
    if (curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK) {
        socExit(); free(socket_buffer); socket_buffer=NULL;
        snprintf(init_error,sizeof(init_error),"HTTPS indisponible."); return false;
    }
    initialized=true; current.state=HTTP_IDLE;
    return true;
}

static bool start_impl(const char *url, const char *file_path, size_t max_bytes, bool range) {
    if (!initialized || !url || strncmp(url,"https://",8) || strlen(url)>=sizeof(request_url) ||
        (file_path && strlen(file_path)>=sizeof(request_file)) || !max_bytes) return false;
    ia_http_reset();
    LightLock_Lock(&lock);
    if (running) { LightLock_Unlock(&lock); return false; }
    snprintf(request_url,sizeof(request_url),"%s",url);
    snprintf(request_file,sizeof(request_file),"%s",file_path ? file_path : "");
    request_max=max_bytes; request_range=range; cancel_requested=false;
    memset(&current,0,sizeof(current)); current.state=HTTP_BUSY;
    running=true;
    LightLock_Unlock(&lock);
    /* TLS and redirects can require considerably more stack than the callback itself. */
    worker=threadCreate(run_request,NULL,0x20000,0x30,-2,false);
    if (!worker) {
        LightLock_Lock(&lock);
        running=false; current.state=HTTP_ERROR;
        snprintf(current.error,sizeof(current.error),"Tache reseau impossible.");
        LightLock_Unlock(&lock);
        return false;
    }
    return true;
}

bool ia_http_start(const char *url, const char *file_path, size_t max_bytes) {
    return start_impl(url,file_path,max_bytes,false);
}

bool ia_http_start_range(const char *url, const char *file_path, size_t max_bytes) {
    return file_path && start_impl(url,file_path,max_bytes,true);
}

HttpSnapshot ia_http_snapshot(void) {
    LightLock_Lock(&lock); HttpSnapshot copy=current; LightLock_Unlock(&lock); return copy;
}

char *ia_http_take_body(size_t *length) {
    LightLock_Lock(&lock);
    char *body=NULL;
    if (current.state==HTTP_DONE && !request_file[0]) {
        body=response_body; response_body=NULL;
        if (length) *length=response_length;
    }
    LightLock_Unlock(&lock);
    return body;
}

void ia_http_reset(void) {
    LightLock_Lock(&lock); bool can_join=worker && !running; LightLock_Unlock(&lock);
    if (can_join) { threadJoin(worker,UINT64_MAX); threadFree(worker); worker=NULL; }
    if (can_join || !worker) {
        free(response_body); response_body=NULL; response_length=0;
        LightLock_Lock(&lock); if (!running) current.state=HTTP_IDLE; LightLock_Unlock(&lock);
    }
}

void ia_http_cancel(void) {
    LightLock_Lock(&lock); cancel_requested=true; LightLock_Unlock(&lock);
}

void ia_http_exit(void) {
    if (!initialized) return;
    ia_http_cancel();
    if (worker) { threadJoin(worker,UINT64_MAX); threadFree(worker); worker=NULL; }
    ia_http_reset();
    curl_global_cleanup(); socExit();
    free(socket_buffer); socket_buffer=NULL;
    initialized=false;
}

const char *ia_http_init_error(void) { return init_error; }
