#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <ctype.h>
#include "audio.h"
#include "ia_http.h"
#include "ia_model.h"
#include "cover.h"

enum { VIEW_SEARCH, VIEW_TRACKS, VIEW_OPTIONS, VIEW_GUIDE, VIEW_QUEUE };
enum { OP_NONE, OP_SEARCH, OP_ITEM, OP_DOWNLOAD, OP_PREVIEW, OP_COVER };
#define QUEUE_MAX 24
#define APP_DIR "sdmc:/3ds/ShieldOSTArchives"
#define OUT_DIR "sdmc:/download audio"

typedef struct { char id[128]; IaTrack track; } QueueEntry;
static QueueEntry queue[QUEUE_MAX];
static unsigned queue_count;
static bool queue_paused;
static unsigned queue_selected;
static bool remove_active_after_cancel;
static char confirmed_queue_id[128], confirmed_queue_name[256];
static C3D_RenderTarget *top, *bottom;
static C2D_TextBuf text_buf;
static IaSearchPage search_page;
static IaItem *item;
static int view, parent_view, selected, search_page_num=1, track_page_num=1;
static int search_selection_before_item;
static int operation, confirmation, guide_page, deferred_action;
static IaTrack confirmed_track;
static char confirmed_id[128];
static bool net_ready, audio_ready, preview_active, from_queue;
static uint64_t download_expected;
static int theme_choice;
static char query[96], notice[160], target_path[512], temp_path[512], preview_path[512], pending_id[128];
static char pending_search_query[96];
static int pending_search_page;
static uint64_t notice_until, preview_until;
static uint32_t navy,panel,raised,accent,white,muted,green,amber;
static Cover covers[4];
static char cover_urls[4][768],cover_paths[4][512],cover_temp[512],cover_target[512];
static bool cover_failed[4];
static int cover_active_slot=-1;

static void theme_set(int t) {
    theme_choice=t;
    if (t) { navy=C2D_Color32(6,6,8,255); panel=C2D_Color32(28,28,30,255);
        raised=C2D_Color32(53,53,56,255); accent=C2D_Color32(242,242,242,255);
        white=C2D_Color32(255,255,255,255); muted=C2D_Color32(170,170,174,255);
        green=C2D_Color32(240,240,240,255); amber=C2D_Color32(190,190,190,255); }
    else { navy=C2D_Color32(3,18,34,255); panel=C2D_Color32(9,35,57,255);
        raised=C2D_Color32(15,53,77,255); accent=C2D_Color32(23,207,232,255);
        white=C2D_Color32(239,249,255,255); muted=C2D_Color32(151,185,199,255);
        green=C2D_Color32(89,220,157,255); amber=C2D_Color32(248,178,81,255); }
}

static void say(const char *s) {
    snprintf(notice,sizeof(notice),"%s",s ? s : "");
    notice_until=osGetTime()+5500;
}

static void shape(float x,float y,float w,float h,float r,u32 color) {
    if (w<=r*2 || h<=r*2) return;
    C2D_DrawRectSolid(x+r,y,0,w-r*2,h,color);
    C2D_DrawRectSolid(x,y+r,0,w,h-r*2,color);
    C2D_DrawCircleSolid(x+r,y+r,0,r,color);
    C2D_DrawCircleSolid(x+w-r,y+r,0,r,color);
    C2D_DrawCircleSolid(x+r,y+h-r,0,r,color);
    C2D_DrawCircleSolid(x+w-r,y+h-r,0,r,color);
}

static void label(const char *s,float x,float y,float scale,float width,u32 color) {
    if (!s || !*s) return;
    char clipped[256]; snprintf(clipped,sizeof(clipped),"%s",s);
    size_t len=strlen(clipped);
    C2D_Text t; float actual=0,height=0;
    C2D_TextParse(&t,text_buf,clipped); C2D_TextOptimize(&t);
    C2D_TextGetDimensions(&t,scale,scale,&actual,&height);
    while (width>0 && actual>width && len>4) {
        len-=2;
        while (len && ((unsigned char)clipped[len]&0xC0)==0x80) --len;
        memcpy(clipped+len,"...",4);
        C2D_TextParse(&t,text_buf,clipped); C2D_TextOptimize(&t);
        C2D_TextGetDimensions(&t,scale,scale,&actual,&height);
    }
    C2D_DrawText(&t,C2D_WithColor,x,y,0,scale,scale,color);
}

static const IaTrack *selected_track(void) {
    unsigned n=ia_page_first((unsigned)track_page_num)+(unsigned)selected;
    return item && n<item->count ? &item->tracks[n] : NULL;
}

static const IaArchive *selected_archive(void) {
    return selected>=0 && (unsigned)selected<search_page.count ?
        &search_page.archives[selected] : NULL;
}

static void ensure_folders(void) {
    mkdir("sdmc:/3ds",0777); mkdir(APP_DIR,0777);
    mkdir(APP_DIR "/covers",0777); mkdir(OUT_DIR,0777);
}

static void covers_prepare(void) {
    ensure_folders();
    for (int i=0;i<4;++i) {
        cover_clear(&covers[i]); cover_failed[i]=false;
        cover_urls[i][0]=cover_paths[i][0]=0;
        const char *id=NULL,*picture=NULL;
        if (view==VIEW_SEARCH && (unsigned)i<search_page.count)
            id=search_page.archives[i].identifier;
        else if (view==VIEW_TRACKS && item) {
            unsigned index=ia_page_first((unsigned)track_page_num)+(unsigned)i;
            if (index<item->count) {
                id=item->archive.identifier;
                picture=item->tracks[index].cover_file;
            }
        }
        if (!id || !ia_build_cover_url(id,picture,cover_urls[i],sizeof(cover_urls[i]))) continue;
        uint32_t hash=2166136261u;
        for (const unsigned char *p=(const unsigned char *)cover_urls[i];*p;++p)
            hash=(hash^*p)*16777619u;
        snprintf(cover_paths[i],sizeof(cover_paths[i]),APP_DIR "/covers/%08lX.img",(unsigned long)hash);
    }
}

static void covers_update(void) {
    if (view!=VIEW_SEARCH && view!=VIEW_TRACKS) return;
    for (int i=0;i<4;++i) {
        if (!cover_urls[i][0] || cover_failed[i] || covers[i].loaded) continue;
        struct stat info;
        if (stat(cover_paths[i],&info)==0) {
            if (!cover_load(&covers[i],cover_paths[i])) cover_failed[i]=true;
            return;
        }
        if (operation || queue_count || !net_ready) return;
        snprintf(cover_temp,sizeof(cover_temp),"%s.part",cover_paths[i]);
        if (ia_http_start(cover_urls[i],cover_temp,524288)) {
            snprintf(cover_target,sizeof(cover_target),"%s",cover_paths[i]);
            cover_active_slot=i; operation=OP_COVER;
        } else cover_failed[i]=true;
        return;
    }
}

static void save_theme(void) {
    ensure_folders(); FILE *f=fopen(APP_DIR "/theme.dat","wb");
    if (f) { fputc('0'+theme_choice,f); fclose(f); }
}

static void load_theme(void) {
    int t=0; FILE *f=fopen(APP_DIR "/theme.dat","rb");
    if (f) { t=fgetc(f)=='1'; fclose(f); } theme_set(t);
}

static void save_queue(void) {
    ensure_folders();
    FILE *f=fopen(APP_DIR "/queue.tmp","wb");
    if (!f) { say("File d'attente : ecriture SD impossible."); return; }
    const char magic[8]={'S','O','S','T','Q','0','1',0};
    bool ok=fwrite(magic,1,8,f)==8 && fwrite(&queue_count,sizeof(queue_count),1,f)==1 &&
        fwrite(queue,sizeof(queue[0]),queue_count,f)==queue_count;
    if (fclose(f)!=0) ok=false;
    if (ok) {
        remove(APP_DIR "/queue.bak");
        rename(APP_DIR "/queue.bin",APP_DIR "/queue.bak");
        if (rename(APP_DIR "/queue.tmp",APP_DIR "/queue.bin")!=0) {
            rename(APP_DIR "/queue.bak",APP_DIR "/queue.bin");
            remove(APP_DIR "/queue.tmp"); say("File d'attente : sauvegarde impossible.");
        }
    } else { remove(APP_DIR "/queue.tmp"); say("File d'attente : sauvegarde impossible."); }
}

static bool load_queue_file(const char *path) {
    FILE *f=fopen(path,"rb"); if (!f) return false;
    char magic[8]; unsigned count=0;
    bool ok=fread(magic,1,8,f)==8 && !memcmp(magic,"SOSTQ01",7) &&
        fread(&count,sizeof(count),1,f)==1 && count<=QUEUE_MAX &&
        fread(queue,sizeof(queue[0]),count,f)==count;
    fclose(f); if (!ok) return false;
    queue_count=0;
    char url[768];
    for (unsigned i=0;i<count;++i) {
        queue[i].id[sizeof(queue[i].id)-1]=0;
        queue[i].track.name[sizeof(queue[i].track.name)-1]=0;
        queue[i].track.title[sizeof(queue[i].track.title)-1]=0;
        if (ia_build_file_url(queue[i].id,queue[i].track.name,url,sizeof(url)) &&
            queue[i].track.format<=IA_AUDIO_M4A)
            queue[queue_count++]=queue[i];
    }
    return true;
}

static void load_queue(void) {
    if (!load_queue_file(APP_DIR "/queue.bin")) {
        if (load_queue_file(APP_DIR "/queue.bak")) say("File d'attente recuperee depuis la sauvegarde.");
    }
}

static bool network_ready(void) {
    if (net_ready) return true;
    net_ready=ia_http_init();
    if (!net_ready) say(ia_http_init_error());
    return net_ready;
}

static void keyboard(void) {
    SwkbdState k; char result[sizeof(query)]={0};
    swkbdInit(&k,SWKBD_TYPE_NORMAL,2,sizeof(query)-1);
    swkbdSetHintText(&k,"Rechercher des archives audio");
    swkbdSetInitialText(&k,query);
    swkbdSetButton(&k,SWKBD_BUTTON_RIGHT,"OK",true);
    if (swkbdInputText(&k,result,sizeof(result))==SWKBD_BUTTON_RIGHT && strcmp(query,result)) {
        snprintf(query,sizeof(query),"%s",result);
        deferred_action=0;
        if (operation==OP_SEARCH) ia_http_cancel();
        if (operation==OP_COVER) ia_http_cancel();
        memset(&search_page,0,sizeof(search_page)); search_page_num=1;
        view=VIEW_SEARCH; selected=0; covers_prepare();
    }
}

static void begin_search(void) {
    if (!*query) { say("Entrez un titre ou un artiste."); return; }
    if (operation==OP_COVER || operation==OP_SEARCH || operation==OP_ITEM) {
        ia_http_cancel(); deferred_action=OP_SEARCH; say("Nouvelle recherche en attente..."); return;
    }
    if (operation) { say("Attendez la fin du transfert ou annulez-le."); return; }
    if (!network_ready()) return;
    char url[768];
    if (!ia_build_search_url(query,(unsigned)search_page_num,url,sizeof(url)) ||
        !ia_http_start(url,NULL,1048576)) { say("Recherche impossible."); return; }
    snprintf(pending_search_query,sizeof(pending_search_query),"%s",query);
    pending_search_page=search_page_num;
    operation=OP_SEARCH; say("Recherche Internet Archive en cours...");
}

static void begin_item(void) {
    const IaArchive *entry=selected_archive();
    if (operation==OP_COVER) { ia_http_cancel(); deferred_action=OP_ITEM; return; }
    if (!entry || operation || !network_ready()) return;
    char url[768];
    if (!ia_build_metadata_url(entry->identifier,url,sizeof(url)) ||
        !ia_http_start(url,NULL,2097152)) { say("Archives indisponibles."); return; }
    snprintf(pending_id,sizeof(pending_id),"%s",entry->identifier);
    operation=OP_ITEM; say("Chargement des pistes...");
}

static uint64_t sd_free_bytes(void) {
    FS_ArchiveResource sd;
    if (R_FAILED(FSUSER_GetSdmcArchiveResource(&sd))) return 0;
    return (uint64_t)sd.freeClusters*sd.clusterSize;
}

static void safe_name(const char *input,char *out,size_t cap) {
    const char *base=strrchr(input,'/'); base=base ? base+1 : input;
    size_t at=0;
    for (const unsigned char *p=(const unsigned char *)base; *p && at<cap-1; ++p)
        out[at++]=(*p<32 || *p==127 || *p=='<' || *p=='>' || *p==':' ||
            *p=='"' || *p=='/' || *p=='\\' || *p=='|' || *p=='?' || *p=='*') ? '_' : (char)*p;
    out[at]=0;
    if (!at || !strcmp(out,".") || !strcmp(out,"..")) snprintf(out,cap,"audio.dat");
}

static bool begin_download(const char *id,const IaTrack *track,bool queued) {
    if (operation || !track || !track->downloadable || !network_ready()) return false;
    char url[768],filename[128];
    if (!ia_build_file_url(id,track->name,url,sizeof(url))) { say("Lien audio invalide."); return false; }
    uint64_t free_bytes=sd_free_bytes();
    if (free_bytes<36u*1024u*1024u ||
        (track->bytes && track->bytes>free_bytes-4u*1024u*1024u)) {
        say("Espace libre SD insuffisant ou inconnu."); return false;
    }
    ensure_folders(); safe_name(track->name,filename,sizeof(filename));
    int suffix=0; struct stat info;
    do {
        if (suffix) snprintf(target_path,sizeof(target_path),OUT_DIR "/%d_%s",suffix,filename);
        else snprintf(target_path,sizeof(target_path),OUT_DIR "/%s",filename);
        ++suffix;
    } while (stat(target_path,&info)==0 && suffix<1000);
    if (suffix>=1000) { say("Trop de fichiers du meme nom."); return false; }
    snprintf(temp_path,sizeof(temp_path),APP_DIR "/download-%llu.part",
             (unsigned long long)osGetTime());
    uint64_t available=free_bytes-4u*1024u*1024u;
    size_t max_bytes=(size_t)(available<512u*1024u*1024u ? available : 512u*1024u*1024u);
    if (!ia_http_start(url,temp_path,max_bytes)) { say("Telechargement impossible."); return false; }
    download_expected=track->bytes;
    from_queue=queued; operation=OP_DOWNLOAD; say("Telechargement en cours..."); return true;
}

static void enqueue(const char *id,const IaTrack *track,bool front) {
    if (!track || !track->downloadable) { say("Cette piste n'est pas telechargeable."); return; }
    if (queue_count>=QUEUE_MAX) { say("File d'attente pleine."); return; }
    for (unsigned i=0;i<queue_count;++i)
        if (!strcmp(queue[i].id,id) && !strcmp(queue[i].track.name,track->name)) {
            say("Deja dans la file d'attente."); return;
        }
    if (front) memmove(queue+1,queue,queue_count*sizeof(queue[0]));
    unsigned at=front ? 0 : queue_count;
    snprintf(queue[at].id,sizeof(queue[at].id),"%s",id);
    queue[at].track=*track; ++queue_count; save_queue();
    queue_paused=false; say("Piste ajoutee a la file.");
}

static void start_preview(void) {
    const IaTrack *track=selected_track();
    if (operation==OP_PREVIEW) { ia_http_cancel(); say("Annulation de la preecoute..."); return; }
    if (preview_active) {
        audio_stop(); preview_active=false; remove(preview_path);
        say("Preecoute arretee."); return;
    }
    if (operation==OP_COVER) { ia_http_cancel(); deferred_action=OP_PREVIEW; return; }
    if (view!=VIEW_TRACKS || !track || operation) return;
    if (track->format==IA_AUDIO_M4A && (!track->bytes || track->bytes>4u*1024u*1024u)) {
        say("M4A trop long pour une preecoute partielle."); return;
    }
    if (!audio_ready || !network_ready()) { say("Audio ou reseau indisponible."); return; }
    char url[768];
    if (!ia_build_file_url(item->archive.identifier,track->name,url,sizeof(url))) {
        say("Lien audio invalide."); return;
    }
    ensure_folders();
    snprintf(preview_path,sizeof(preview_path),APP_DIR "/preview.%s",
             ia_format_name(track->format));
    size_t limit=track->format==IA_AUDIO_MP3 || track->format==IA_AUDIO_AAC ?
        3u*1024u*1024u : 4u*1024u*1024u;
    if (!ia_http_start_range(url,preview_path,limit)) { say("Preecoute impossible."); return; }
    operation=OP_PREVIEW; say("Preparation de la preecoute...");
}

static void remove_first_queue(void) {
    if (!queue_count) return;
    --queue_count; memmove(queue,queue+1,queue_count*sizeof(queue[0])); save_queue();
    if (queue_selected>=queue_count) queue_selected=queue_count ? queue_count-1 : 0;
}

static void run_deferred(void) {
    int action=deferred_action; deferred_action=0;
    if (action==OP_SEARCH) begin_search();
    else if (action==OP_ITEM) begin_item();
    else if (action==OP_PREVIEW) start_preview();
}

static void poll_network(void) {
    if (net_ready && operation) {
        HttpSnapshot state=ia_http_snapshot();
        if (state.state==HTTP_BUSY) return;
        int finished=operation; operation=OP_NONE;
        if (state.state==HTTP_ERROR) {
            if (finished!=OP_COVER) say(state.error);
            else if (cover_active_slot>=0 && cover_active_slot<4 &&
                     !strcmp(cover_paths[cover_active_slot],cover_target))
                cover_failed[cover_active_slot]=true;
            if (finished==OP_DOWNLOAD && from_queue) {
                if (remove_active_after_cancel) {
                    remove_active_after_cancel=false; remove_first_queue();
                    queue_paused=false;
                } else queue_paused=true;
            }
            if (finished==OP_PREVIEW) remove(preview_path);
            ia_http_reset();
            if (deferred_action) run_deferred();
            return;
        }
        if (state.state!=HTTP_DONE) return;
        if (finished==OP_SEARCH || finished==OP_ITEM) {
            size_t bytes=0; char *body=ia_http_take_body(&bytes);
            if (finished==OP_SEARCH) {
                IaSearchPage found;
                if (strcmp(pending_search_query,query) || pending_search_page!=search_page_num) {
                    /* A newer query superseded this completed response. */
                } else if (body && ia_parse_search(body,bytes,(unsigned)search_page_num,&found)) {
                    search_page=found; selected=0; view=VIEW_SEARCH; covers_prepare();
                    say(found.count ? "Archives trouvees." : "Aucun resultat pour cette recherche.");
                } else say("Reponse de recherche invalide.");
            } else {
                IaItem *found=malloc(sizeof(*found));
                if (found && body && ia_parse_item(body,bytes,pending_id,found)) {
                    free(item); item=found; found=NULL;
                    search_selection_before_item=selected; selected=0; track_page_num=1;
                    view=VIEW_TRACKS; covers_prepare();
                    say(item->count ? "Pistes chargees." : "Aucune piste audio dans cette archive.");
                } else say("Metadonnees indisponibles ou trop volumineuses.");
                free(found);
            }
            free(body);
        } else if (finished==OP_DOWNLOAD) {
            if (download_expected && state.received!=download_expected) {
                remove(temp_path); queue_paused=from_queue;
                say("Taille du fichier recue incoherente.");
            } else if (rename(temp_path,target_path)==0) {
                if (from_queue) remove_first_queue();
                say("Telechargement termine.");
            } else { remove(temp_path); queue_paused=from_queue;
                say("Enregistrement final sur SD impossible."); }
        } else if (finished==OP_PREVIEW) {
            if (audio_open(preview_path,0)) {
                preview_active=true; preview_until=osGetTime()+60000;
                say("Preecoute : B pour arreter.");
            } else { say(audio_error()); remove(preview_path); }
        } else if (finished==OP_COVER && cover_active_slot>=0 && cover_active_slot<4) {
            int slot=cover_active_slot;
            if (rename(cover_temp,cover_target)==0) {
                if (!strcmp(cover_paths[slot],cover_target) &&
                    !cover_load(&covers[slot],cover_target)) cover_failed[slot]=true;
            } else { remove(cover_temp); if (!strcmp(cover_paths[slot],cover_target)) cover_failed[slot]=true; }
        }
        ia_http_reset();
        if (deferred_action) run_deferred();
    }
    if (!operation && !queue_paused && queue_count) {
        if (!begin_download(queue[0].id,&queue[0].track,true)) queue_paused=true;
    }
    if (!operation) covers_update();
}

static void text_time(uint32_t ms,char out[16]) {
    if (!ms) snprintf(out,16,"--:--");
    else snprintf(out,16,"%02u:%02u",(unsigned)(ms/60000),(unsigned)(ms/1000%60));
}

static void draw_top(void) {
    C2D_SceneBegin(top); C2D_TargetClear(top,navy);
    shape(10,8,380,224,12,panel);
    shape(18,15,364,32,8,raised);
    label("SHIELD",28,18,.72f,130,white);
    label("ONLINE ARCHIVE",148,21,.49f,165,accent);
    label("v0.2",345,23,.39f,32,muted);
    if (view==VIEW_TRACKS && item) {
        label(item->archive.title,22,53,.49f,preview_active ? 195 : 350,white);
        if (preview_active) {
            char elapsed[16],limit[16],status[48];
            uint32_t duration=audio_duration_ms();
            if (!duration || duration>60000) duration=60000;
            text_time(audio_position_ms(),elapsed); text_time(duration,limit);
            snprintf(status,sizeof(status),"Ecoute %s/%s",elapsed,limit);
            label(status,226,55,.39f,145,accent);
        }
        for (unsigned i=0;i<4;++i) {
            unsigned index=ia_page_first((unsigned)track_page_num)+i;
            float x=22+(i%2)*182, y=78+(i/2)*67;
            shape(x,y,172,60,8,index<item->count && (int)i==selected ? accent : raised);
            if (index<item->count) {
                shape(x+2,y+2,168,56,7,navy);
                if (covers[i].loaded) cover_draw(&covers[i],x+3,y+3,54);
                else {
                    C2D_DrawCircleSolid(x+24,y+25,0,15,raised);
                    C2D_DrawCircleSolid(x+24,y+25,0,7,accent);
                }
                label(item->tracks[index].title,x+46,y+10,.45f,117,white);
                label(ia_format_name(item->tracks[index].format),x+46,y+34,.39f,109,muted);
            }
        }
        if (item->truncated) label("Liste partielle : archive tres grande",24,215,.37f,330,amber);
    } else if (view==VIEW_SEARCH && search_page.count) {
        label("ARCHIVES AUDIO",24,57,.61f,340,white);
        for (unsigned i=0;i<search_page.count;++i) {
            float x=22+(i%2)*182, y=81+(i/2)*64;
            shape(x,y,172,58,8,(int)i==selected ? accent : raised);
            shape(x+2,y+2,168,54,7,navy);
            if (covers[i].loaded) cover_draw(&covers[i],x+3,y+2,54);
            else {
                C2D_DrawCircleSolid(x+24,y+25,0,14,raised);
                C2D_DrawCircleSolid(x+24,y+25,0,6,accent);
            }
            label(search_page.archives[i].title,x+45,y+9,.46f,118,white);
            label(search_page.archives[i].creator,x+45,y+33,.37f,119,muted);
        }
    } else {
        C2D_DrawCircleSolid(94,135,0,64,raised);
        C2D_DrawCircleSolid(94,135,0,54,navy);
        C2D_DrawCircleSolid(94,135,0,44,raised);
        C2D_DrawCircleSolid(94,135,0,36,navy);
        C2D_DrawCircleSolid(94,135,0,23,accent);
        label("Vos archives audio",175,82,.62f,192,white);
        label("Internet Archive",175,112,.50f,195,accent);
        label("Recherchez un titre ou artiste",175,146,.44f,190,muted);
        label("Puis choisissez Audio",175,172,.44f,190,muted);
    }
    if (view==VIEW_SEARCH || view==VIEW_TRACKS) {
        unsigned page=view==VIEW_SEARCH ? (unsigned)search_page_num : (unsigned)track_page_num;
        unsigned total=view==VIEW_SEARCH ? ia_page_count(search_page.total) :
            item ? ia_page_count(item->count) : 0;
        char pages[32]; snprintf(pages,sizeof(pages),"%u/%u",total ? page : 0,total);
        shape(22,207,356,23,6,raised);
        label("L <",32,210,.43f,45,white);
        label(pages,179,210,.44f,55,accent);
        label("> R",339,210,.43f,40,white);
    }
    if (*notice && osGetTime()<notice_until) {
        shape(21,204,358,25,6,raised); label(notice,28,208,.43f,342,white);
    }
}

static void draw_bottom(void) {
    C2D_SceneBegin(bottom); C2D_TargetClear(bottom,navy);
    if (view==VIEW_OPTIONS || view==VIEW_GUIDE || view==VIEW_QUEUE) {
        shape(8,8,304,225,12,panel);
        if (view==VIEW_OPTIONS) {
            label("OPTIONS",19,16,.71f,270,white);
            label("Theme visuel",19,50,.49f,275,accent);
            shape(17,77,134,34,8,theme_choice ? raised : accent);
            shape(169,77,134,34,8,theme_choice ? accent : raised);
            label("Bleu cyber",28,84,.50f,110,theme_choice ? white : navy);
            label("Noir / blanc",178,84,.50f,112,theme_choice ? navy : white);
            shape(17,129,286,34,8,raised); label("File d'attente",27,136,.51f,256,white);
            shape(17,175,286,34,8,raised); label("Guide et credits",27,182,.51f,256,white);
            label("SELECT/B Retour",19,214,.42f,255,muted);
        } else if (view==VIEW_QUEUE) {
            char title[32]; snprintf(title,sizeof(title),"FILE  %u/%d",queue_count,QUEUE_MAX);
            label(title,19,16,.65f,270,white);
            unsigned first=(queue_selected/5)*5;
            for (unsigned i=first;i<queue_count && i<first+5;++i) {
                int y=52+(int)(i-first)*27;
                if (i==queue_selected) shape(16,y-3,288,25,6,raised);
                label(queue[i].track.title,21,y,.45f,216,i==queue_selected ? white : muted);
                label(i==0 && operation==OP_DOWNLOAD && from_queue ? "ACTIF" : "ATTENTE",
                      241,y+2,.42f,59,i==0 ? accent : muted);
            }
            if (!queue_count) label("Aucun telechargement en attente",20,88,.44f,280,muted);
            if (queue_paused && queue_count) label("Transfert interrompu. A pour reprendre.",18,190,.39f,286,amber);
            if (operation==OP_DOWNLOAD && from_queue) {
                HttpSnapshot h=ia_http_snapshot();
                if (h.expected) {
                    float progress=275.0f*(float)((double)h.received/(double)h.expected);
                    if (progress>275) progress=275;
                    shape(20,207,275,5,2,raised);
                    if (progress>4) shape(20,207,progress,5,2,accent);
                }
            }
            label("A Reprendre   X Retirer   B Retour",18,218,.39f,290,muted);
        } else {
            char head[32]; snprintf(head,sizeof(head),"GUIDE %d/4",guide_page);
            label(head,19,15,.69f,270,white);
            const char *lines[4][5]={
                {"Rechercher ouvre le clavier tactile.","Saisissez un titre ou un artiste.","Audio lance la recherche en ligne.","A ouvre une archive puis une piste.","L/R change de page."},
                {"Y lance ou arrete la preecoute.","A propose de telecharger la piste.","X ajoute une piste a la file.","Les fichiers vont dans download audio.","B revient a la page precedente."},
                {"SELECT ouvre les options et le theme.","Une erreur reseau ne modifie pas la SD.","Connexion active requise pour chercher.","Formats affiches selon les fichiers.","La lecture reste en developpement."},
                {"Idee et audios : Neo Foxy76.","Conception : Shield-77.","Code : aide de Codex / OpenAI.","Audio AAC : FAAD2 / Nero AG.","Projet gratuit, fait sur temps libre."}
            };
            int page=guide_page>=1 && guide_page<=4 ? guide_page-1 : 0;
            for (int i=0;i<5;++i) label(lines[page][i],18,54+i*29,.44f,284,i==0 ? accent : white);
            label("B Precedent       A Suivant",18,214,.40f,287,muted);
        }
        return;
    }
    shape(9,8,302,36,9,panel);
    label(*query ? query : "Touchez pour rechercher...",17,15,.50f,284,*query ? white : muted);
    shape(9,50,94,31,8,accent); label("Audio",29,56,.54f,60,navy);
    shape(111,50,98,31,8,raised); label("Rechercher",117,57,.46f,90,white);
    shape(217,50,94,31,8,panel); label("Image",239,57,.46f,70,muted);
    unsigned visible=view==VIEW_SEARCH ? search_page.count :
        view==VIEW_TRACKS && item ? item->count-ia_page_first((unsigned)track_page_num) : 0;
    if (visible>4) visible=4;
    for (unsigned i=0;i<visible;++i) {
        float x=215.0f+i*24.0f;
        C2D_DrawCircleSolid(x+9,96,0,10,(int)i==selected ? accent : raised);
        char digit[2]={(char)('1'+i),0};
        label(digit,x+5,90,.39f,12,(int)i==selected ? navy : white);
    }
    if (view==VIEW_SEARCH) {
        char count[64]; snprintf(count,sizeof(count),"Archives : %u",search_page.total);
        label(count,13,88,.48f,180,muted);
        shape(9,112,302,110,9,panel);
        const IaArchive *archive=selected_archive();
        if (archive) {
            label(archive->title,19,120,.60f,282,white);
            label("Archive audio",19,150,.43f,280,accent);
            label(archive->creator[0] ? archive->creator : "Artiste non precise",19,172,.50f,280,white);
            if (archive->archive_date[0]) {
                label("Date de l'archive",19,198,.42f,150,muted);
                label(archive->archive_date,173,197,.45f,120,white);
            }
        } else label("Saisissez un titre, puis touchez Audio",19,143,.48f,280,white);
    } else if (view==VIEW_TRACKS && item) {
        char count[64]; snprintf(count,sizeof(count),"Piste %u/%u",
            ia_page_first((unsigned)track_page_num)+(unsigned)selected+1,item->count);
        label(count,13,88,.48f,180,muted);
        shape(9,112,302,110,9,panel);
        const IaTrack *track=selected_track();
        if (track) {
            char size[32],time[16];
            label(track->title,19,119,.57f,282,white);
            if (track->bytes) snprintf(size,sizeof(size),"%llu Ko",(unsigned long long)((track->bytes+1023)/1024));
            else snprintf(size,sizeof(size),"Inconnue");
            text_time(track->duration_ms,time);
            const char *names[4]={"Format","Duree","Taille","Date"};
            const char *values[4]={ia_format_name(track->format),time,size,
                track->date[0] ? track->date : "Inconnue"};
            for (int i=0;i<4;++i) {
                float y=145+i*18;
                label(names[i],20,y,.43f,95,muted);
                label(values[i],118,y,.49f,180,i==0 ? accent : white);
            }
        }
    }
    shape(9,226,302,12,5,panel);
    if (operation) {
        HttpSnapshot h=ia_http_snapshot();
        if (h.expected && h.received) {
            float width=302.0f*(float)((double)h.received/(double)h.expected);
            if (width>302) width=302;
            if (width>10) shape(9,226,width,12,5,accent);
        }
    } else if (preview_active) {
        uint32_t duration=audio_duration_ms();
        if (!duration || duration>60000) duration=60000;
        float width=302.0f*(float)audio_position_ms()/(float)duration;
        if (width>302) width=302;
        if (width>10) shape(9,226,width,12,5,accent);
    }
}

static void render(void) {
    C2D_TextBufClear(text_buf); C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    draw_top(); draw_bottom(); C3D_FrameEnd(0);
}

static void move_selection(int delta) {
    int count=view==VIEW_SEARCH ? (int)search_page.count :
        item ? (int)(item->count-ia_page_first((unsigned)track_page_num)) : 0;
    if (count>4) count=4;
    if (count<=0) return;
    selected+=delta; if (selected<0) selected=0; if (selected>=count) selected=count-1;
}

static void change_page(int delta) {
    if (view==VIEW_SEARCH) {
        if (operation) return;
        int next=search_page_num+delta;
        if (next<1 || (unsigned)next>ia_page_count(search_page.total)) return;
        search_page_num=next; begin_search();
    } else if (view==VIEW_TRACKS && item) {
        int next=track_page_num+delta;
        if (next<1 || (unsigned)next>ia_page_count(item->count)) return;
        track_page_num=next; selected=0; covers_prepare();
    }
}

static void on_back(void) {
    if (confirmation) { confirmation=0; return; }
    if (view==VIEW_QUEUE) { view=VIEW_OPTIONS; return; }
    if (operation==OP_DOWNLOAD || operation==OP_PREVIEW) {
        ia_http_cancel(); say("Annulation demandee..."); return;
    }
    if (preview_active) {
        audio_stop(); preview_active=false; remove(preview_path);
        say("Preecoute arretee."); return;
    }
    if (view==VIEW_GUIDE) {
        if (guide_page>1) --guide_page; else view=VIEW_OPTIONS;
    } else if (view==VIEW_OPTIONS) view=parent_view;
    else if (view==VIEW_TRACKS) {
        view=VIEW_SEARCH; selected=search_selection_before_item; covers_prepare();
    }
    else if (operation) { ia_http_cancel(); say("Annulation demandee..."); }
}

static void handle_action(void) {
    if (confirmation) {
        int wanted=confirmation; confirmation=0;
        if (wanted==3) {
            if (queue_selected>=queue_count ||
                strcmp(queue[queue_selected].id,confirmed_queue_id) ||
                strcmp(queue[queue_selected].track.name,confirmed_queue_name)) {
                say("La file a change. Selectionnez encore la piste."); return;
            }
            if (queue_selected==0 && operation==OP_DOWNLOAD && from_queue) {
                remove_active_after_cancel=true; ia_http_cancel();
                say("Annulation du transfert demandee...");
            } else {
                memmove(queue+queue_selected,queue+queue_selected+1,
                        (queue_count-queue_selected-1)*sizeof(queue[0]));
                --queue_count; save_queue();
                if (queue_selected>=queue_count) queue_selected=queue_count ? queue_count-1 : 0;
                say("Piste retiree de la file.");
            }
            return;
        }
        if (wanted==1) {
            if (operation==OP_DOWNLOAD || operation==OP_COVER) {
                if (operation==OP_COVER) ia_http_cancel();
                enqueue(confirmed_id,&confirmed_track,true);
            }
            else begin_download(confirmed_id,&confirmed_track,false);
        } else enqueue(confirmed_id,&confirmed_track,false);
        return;
    }
    if (view==VIEW_GUIDE) {
        if (guide_page<4) ++guide_page; else view=VIEW_OPTIONS;
    } else if (view==VIEW_QUEUE) { queue_paused=false; say("File d'attente reprise."); }
    else if (view==VIEW_OPTIONS) { save_theme(); say("Options enregistrees."); }
    else if (view==VIEW_SEARCH) begin_item();
    else if (view==VIEW_TRACKS && selected_track()) {
        confirmed_track=*selected_track();
        snprintf(confirmed_id,sizeof(confirmed_id),"%s",item->archive.identifier);
        confirmation=1; say("Telecharger cette piste ? A oui, B non.");
    }
}

static void handle_touch(int x,int y) {
    if (confirmation) return;
    if (view==VIEW_OPTIONS) {
        if (y>=77 && y<112) { theme_set(x>=160); save_theme(); }
        else if (y>=129 && y<164) view=VIEW_QUEUE;
        else if (y>=175 && y<210) { view=VIEW_GUIDE; guide_page=1; }
        return;
    }
    if (view==VIEW_GUIDE) { if (y>=205) { if (x>=160) handle_action(); else on_back(); } return; }
    if (view==VIEW_QUEUE) {
        if (y>=48 && y<184) {
            unsigned index=(queue_selected/5)*5+(unsigned)((y-48)/27);
            if (index<queue_count) queue_selected=index;
        } else if (y>=213) handle_action();
        return;
    }
    if (y<45) keyboard();
    else if (y>=50 && y<82 && x<104) { search_page_num=1; begin_search(); }
    else if (y>=50 && y<82 && x>=111 && x<209) keyboard();
    else if (y>=84 && y<109 && x>=215 && x<311) {
        int row=(x-215)/24;
        unsigned count=view==VIEW_SEARCH ? search_page.count :
            view==VIEW_TRACKS && item ? item->count-ia_page_first((unsigned)track_page_num) : 0;
        if (row>=0 && row<4 && (unsigned)row<count) selected=row;
    }
}

int main(void) {
    gfxInitDefault();
    if (!C3D_Init(C3D_DEFAULT_CMDBUF_SIZE) || !C2D_Init(4096)) { gfxExit(); return 1; }
    C2D_Prepare(); top=C2D_CreateScreenTarget(GFX_TOP,GFX_LEFT);
    bottom=C2D_CreateScreenTarget(GFX_BOTTOM,GFX_LEFT);
    text_buf=C2D_TextBufNew(8192);
    if (!top || !bottom || !text_buf) { C2D_Fini(); C3D_Fini(); gfxExit(); return 1; }
    for (int i=0;i<4;++i) cover_init(&covers[i]);
    load_theme(); load_queue();
    item=malloc(sizeof(*item));
    if (!item) say("Memoire insuffisante pour le catalogue.");
    audio_ready=audio_init();
    if (!audio_ready) say(audio_error());
    while (aptMainLoop()) {
        hidScanInput(); u32 down=hidKeysDown();
        if (down&KEY_START) { if (operation==OP_DOWNLOAD) say("Attendez ou annulez le transfert."); else break; }
        bool was_playing=audio_playing(); audio_update();
        if (preview_active && osGetTime()>=preview_until) { audio_stop(); preview_active=false; say("Fin de la preecoute."); }
        if (preview_active && was_playing && !audio_playing()) { preview_active=false; say("Fin de la preecoute."); }
        poll_network();
        if (confirmation) {
            if (down&KEY_B) confirmation=0;
            else if (down&KEY_A) handle_action();
        } else if (down&KEY_SELECT) {
            if (view==VIEW_OPTIONS || view==VIEW_GUIDE || view==VIEW_QUEUE) view=parent_view;
            else { parent_view=view; view=VIEW_OPTIONS; }
        } else if (down&KEY_B) on_back();
        else if (down&KEY_A) handle_action();
        else if (view==VIEW_QUEUE) {
            if ((down&KEY_DUP) && queue_selected>0) --queue_selected;
            if ((down&KEY_DDOWN) && queue_selected+1<queue_count) ++queue_selected;
            if ((down&KEY_X) && queue_selected<queue_count) {
                snprintf(confirmed_queue_id,sizeof(confirmed_queue_id),"%s",queue[queue_selected].id);
                snprintf(confirmed_queue_name,sizeof(confirmed_queue_name),"%s",queue[queue_selected].track.name);
                confirmation=3; say("Retirer de la file ? A oui, B non.");
            }
        }
        else if (view==VIEW_TRACKS || view==VIEW_SEARCH) {
            if (down&KEY_DUP) move_selection(-2);
            if (down&KEY_DDOWN) move_selection(2);
            if ((down&KEY_DLEFT) && (selected&1)) move_selection(-1);
            if ((down&KEY_DRIGHT) && !(selected&1)) move_selection(1);
            if (down&KEY_L) change_page(-1);
            if (down&KEY_R) change_page(1);
            if ((down&KEY_Y) && view==VIEW_TRACKS) start_preview();
            if ((down&KEY_X) && view==VIEW_TRACKS && selected_track()) {
                confirmed_track=*selected_track();
                snprintf(confirmed_id,sizeof(confirmed_id),"%s",item->archive.identifier);
                confirmation=2; say("Ajouter a la file ? A oui, B non.");
            }
        }
        if (!confirmation && (down&KEY_TOUCH)) {
            touchPosition p; hidTouchRead(&p);
            handle_touch(p.px,p.py);
        }
        render();
    }
    if (net_ready) ia_http_exit();
    audio_exit(); if (*preview_path) remove(preview_path);
    free(item);
    if (C3D_FrameBegin(0)) C3D_FrameEnd(0);
    for (int i=0;i<4;++i) cover_exit(&covers[i]);
    C2D_TextBufDelete(text_buf);
    C2D_Fini(); C3D_Fini(); gfxExit(); return 0;
}
